#include "interface_header.h"
void Main_Page()
{
     whitecolour();
     system("cls");
     printf("***********************************************************************************************************************");
     printf("                                               MS PAINT                                                                    ");
     printf("***********************************************************************************************************************");
     printf("  ");
     printf("Press 1 to make shapes\n");
     printf("Press 2 to draw on terminal\n");
     printf("Press 3 to Save the file\n");
     printf("Press 4 to view existing file\n");
     printf("Press 5 to edit an existing file\n");
     printf("Press Q to quit\n");
     char ch;
     while (1)
     {
          ch = getch();
          if (ch == '1')
          {
               draw_shapes();
          }
            else if (ch == '2')
          {
               free_draw();
          }
          else if (ch == '3')
          {
               save_file();
          }
          else if (ch == '4')
          {
               viewfile();
          }
          else if (ch == '5')
          {
               edit();
          }
          else if (ch == 'q')
          {
               exit(0);
          }
          else
          {
               Main_Page();
          }
     }
}

void draw_shapes()
{
     gotoxy(0, 0);
     printf("***********************************************************************************************************************");
     printf("                                            Shape Menu                                                                 ");
     printf("***********************************************************************************************************************");
     printf("  ");
     printf("Press a to draw square \n");
     printf("Press b to draw butterfly \n");
     printf("Press c to draw circle \n");
     printf("Press d to draw diamond \n");
     printf("Press e to draw pyramid \n");
     printf("Press f to draw heart \n");
     printf("Press g to draw hexagon \n");
     printf("Press h to draw kite \n");
     printf("Press i to draw line \n");
     printf("Press j to draw oval \n");
     printf("Press k to draw parallalogram \n");
     printf("Press l to draw pentagon \n");
     printf("Press m to draw rectangle \n");
     printf("Press n to draw sandglass \n");
     printf("Press o to draw star \n");
     printf("Press p to draw trapezium \n");
     printf("Press q to draw triangle \n");
     printf("Press r to draw arrows \n");
     printf("Press s to draw chatbox \n");
     printf("Press t to draw alphabets \n");
     printf("Press u to draw numbers \n");
     printf("Press backspace to go back \n");
     char ch;
     while (1)
     {
          ch = getch();

          if (ch == 'a')
          {
               print_square();
          }

          else if (ch == 'b')
          {
               print_butterfly();
          }

          else if (ch == 'c')
          {
               print_circle();
          }

          else if (ch == 'd')
          {
               print_diamond();
          }

          else if (ch == 'e')
          {
               print_pyramid();
          }

          else if (ch == 'f')
          {
               print_heart();
          }

          else if (ch == 'g')
          {
               print_hexagon();
          }

          else if (ch == 'h')
          {
               print_kite();
          }

          else if (ch == 'i')
          {
               print_line();
          }

          else if (ch == 'j')
          {
               print_oval();
          }

          else if (ch == 'k')
          {
               print_parallalogram();
          }

          else if (ch == 'l')
          {
               print_pentagon();
          }

          else if (ch == 'm')
          {
               print_rectangle();
          }

          else if (ch == 'n')
          {
               print_sandglass();
          }

          else if (ch == 'o')
          {
               print_star();
          }

          else if (ch == 'p')
          {
               print_trapezium();
          }

          else if (ch == 'q')
          {
               print_triangle();
          }

          else if (ch == 'r')
          {
               print_arrows();
          }

          else if (ch == 's')
          {
               print_chatbox();
          }

          else if (ch == 't')
          {
               print_alphabets();
          }

          else if (ch == 'u')
          {
               print_numbers();
          }
          else if (ch == 8)
          {
               Main_Page();
          }
     }
}

void print_square()
{
     int size, choice;
     char symbol;
     printf("Enter the size of the square: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for hollow and 2 for filled square:\n");
     printf("1. hollow square\n");
     printf("2. filled square\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
     printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     square(size, choice, symbol, x, y);
}

void print_butterfly()
{
     int size, choice;
     char symbol;
     printf("Enter the size of the butterfly: ");
     scanf("%d", &size);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose 1 for hollow and 2 for filled butterfly:\n");
     printf("1. Hollow butterfly\n");
     printf("2. Filled butterfly\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     butterfly(size, choice, symbol, x, y);
}

void print_circle()
{
     int size, choice;
     char symbol;
     printf("Enter the size of the circle: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for hollow and 2 for filled circle:\n");
     printf("1. hollow circle\n");
     printf("2. filled circle\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     circle(size, choice, symbol, x, y);
}

void print_diamond()
{
     int size, choice;
     char symbol;
     printf("Enter the size of the diamond: ");
     scanf("%d", &size);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose 1 for hollow and 2 for filled diamond:\n");
     printf("1. Hollow Diamond\n");
     printf("2. Filled Diamond\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
     printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     diamond(size, choice, symbol, x, y);
}

void print_pyramid()
{
     int height, choice;
     char symbol;
     printf("Enter the height of the pyramid: ");
     scanf("%d", &height);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose 1 for hollow and 2 for filled pyaramid:\n");
     printf("1. Hollow Pyramid\n");
     printf("2. Filled Pyramid\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
     printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     pyramid(height, choice, symbol, x, y);
}

void print_heart()
{
     int size, choice;
     char symbol;
     printf("Enter the size: ");
     scanf("%d", &size);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for hollow and 2 for filled heart:\n");
     printf("1. hollow heart\n");
     printf("2. filled heart\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
     printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     heart(size, choice, symbol, x, y);
}

void print_hexagon()
{
     int size, choice;
     char symbol;
     printf("Enter the size of the hexagon: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for filled and 2 for hollow hexagon:\n");
     printf("1. filled hexagon\n");
     printf("2. hollow hexagon\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     hexagon(size, choice, symbol, x, y);
}

void print_kite()
{
     int size, choice;
     char symbol;
     printf("Enter the size of the kite: ");
     scanf("%d", &size);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for hollow and 2 for filled kite:\n");
     printf("1. Hollow kite\n");
     printf("2. Filled kite\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     kite(size, choice, symbol, x, y);
}

void print_line()
{
     int length, choice;
     char symbol;
     printf("Enter the length of the line: ");
     scanf("%d", &length);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose 1 for horizonl line and 2 for vertical line\n");
     printf("1. horizontal line\n");
     printf("2. vertical line\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     line(length, choice, symbol, x, y);
}

void print_oval()
{
     int height, width, choice;
     char symbol;

     printf("Enter the height of the oval: ");
     scanf("%d", &height);
     printf("Enter the width of the oval: ");
     scanf("%d", &width);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for filled and 2 for hollow oval:\n");
     printf("1. filled oval\n");
     printf("2. hollow oval\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     oval(height, width, choice, symbol, x, y);
}

void print_parallalogram()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the parallalogram: ");
     scanf("%d", &size);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for filled and 2 for hollow parallalogram:\n");
     printf("1. filled parallalogram\n");
     printf("2. hollow parallalogram\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     parallalogram(size, choice, symbol, x, y);
}

void print_pentagon()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the pentagon: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for hollow and 2 for filled pentagon:\n");
     printf("1. Hollow pentagon\n");
     printf("2. Filled pentagon\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     pentagon(size, choice, symbol, x, y);
}

void print_rectangle()
{
     int rows, columns, choice;
     char symbol;

     printf("Enter the rows of the rectangle: ");
     scanf("%d", &rows);
     printf("Enter the column of the rectangle: ");
     scanf("%d", &columns);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for hollow and 2 for filled rectangle:\n");
     printf("1. hollow rectangle\n");
     printf("2. filled rectangle\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     rectangle(rows, columns, choice, symbol, x, y);
}

void print_sandglass()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the sandglass: ");
     scanf("%d", &size);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for hollow and 2 for filled sandglass:\n");
     printf("1. Hollow sandglass\n");
     printf("2. Filled sandglass\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
     printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     sandglass(size, choice, symbol, x, y);
}

void print_star()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the star: ");
     scanf("%d", &size);

     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("1. Hollow 6 sided Star\n");
     printf("2. Filled 6 sided Star\n");
     printf("3. Hollow 4 sided Star\n");
     printf("4. Filled 4 sided Star\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     star(size, choice, symbol, x, y);
}

void print_trapezium()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the trapezium: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("Choose 1 for filled and 2 for hollow trapezium:\n");
     printf("1. filled trapezium\n");
     printf("2. hollow trapezium\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     trapezium(size, choice, symbol, x, y);
}

void print_triangle()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the triangle: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("1. increasing triangle\n");
     printf("2. hollow increasing triangle\n");
     printf("3. decreasingtriangle\n");
     printf("4. hollow decreasing triangle\n");
     printf("5. right increasing triangle\n");
     printf("6.hollow right increasing triangle\n");
     printf("7. rightdecreasingtriangle\n");
     printf("8.hollow right decreasing triangle\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     triangle(size, choice, symbol, x, y);
}

void print_arrows()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the arrow: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);

     printf("Choose an option:\n");
     printf("1. right arrow\n");
     printf("2. left arrow\n");
     printf("3. up arrow\n");
     printf("4. down arrow\n");

     scanf("%d", &choice);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     arrows(size, choice, symbol, x, y);
}
void print_chatbox()
{
     int size, choice;
     char symbol;

     printf("Enter the size of the chatbox: ");
     scanf("%d", &size);
     printf("Enter the symbol: ");
     scanf(" %c", &symbol);
     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
      printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     chatbox(size, symbol, x, y);
}

void print_numbers()
{
     int size, choice;
     char symbol;

     printf("enter size:");
     scanf("%d", &size);

     printf("enter the symbol:");
     scanf(" %c", &symbol);

     int start, end;
     printf("enter starting number:");
     scanf("%d", &start);
     printf("enter ending number:");
     scanf("%d", &end);

     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
     printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     for (choice = start; choice <= end; choice++)
     {      
          numbers(size, choice, symbol, x, y);
          y=y+size+5;
     }
}

void print_alphabets()
{
     int size, choice;
     char symbol;

     printf("Enter the size : ");
     scanf("%d", &size);
     printf("Enter the symbol : ");
     scanf(" %c", &symbol);

     char start, end;
     printf("Enter the starting letter:");
     scanf(" %c", &start);
     printf("Enter the Ending letter:");
     scanf(" %c", &end);

     int x;
     int y;
     printf("enter the value of x cordinate");
     scanf("%d", &x);
     printf("enter the value of y cordinate");
     scanf("%d", &y);

     char clr;
     printf("enter colour b for blue r for red y for yellow g for green w for white \n");
     scanf(" %c", &clr);
     gotoxy(x, y);
     colour(clr);
     for (choice = start; choice <= end; choice++)
     {
          alphabets(size, choice, symbol, x, y);   
           y=y+size+5;
     }
}

void free_draw()
{
     int x = 0;
     int y = 0;
system("cls");
     while (1)
     {
          if (_kbhit())
          {
               int key = _getch();

               if (key == 0 || key == 224)
               {
                    key = _getch();
                    switch (key)
                    {
                    case 72: // Up arrow
                         y--;
                         break;
                    case 80: // Down arrow
                         y++;
                         break;
                    case 75: // Left arrow
                         x--;
                         break;
                    case 77: // Right arrow
                         x++;
                         break;
                    }
               }
               else
               {  
                    int color = COLOR_RESET;
                    switch (key)
                    {
                    case ' ':
                         break;
                    case 'r':
                         color = COLOR_RED;
                         break;
                    case 'g':
                         color = COLOR_GREEN;
                         break;
                    case 'y':
                         color = COLOR_YELLOW;
                         break;
                    case 'b':
                         color = COLOR_BLUE;
                         break;
                    case 'm' :
                     Main_Page();
                     break;

                    }
                    colorselection(color);
                    printf("*");
                    colorselection(COLOR_RESET);
               }

               COORD coord = {x, y};
               HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
               SetConsoleCursorPosition(hConsole, coord);
          }
     }
}

void save_file()
{
     fclose(fptr);

     char ch;
     fclose(fptr);
     FILE *fptr2;
     char file_name[100];
     printf("Enter file name: ");
     gets(file_name);
     gets(file_name);
     strcat(file_name, ".txt");
     fptr = fopen("default.txt", "r");
     fptr2 = fopen(file_name, "w"); // Use "a" mode for appending/creating

     if (fptr2 == NULL)
     {
          printf("Error creating/appending the file");
     }
     while ((ch = fgetc(fptr)) != EOF)
     {
          fputc(ch, fptr2);
     }
     fclose(fptr);
}

void default_save()
{
     fptr = fopen("default.txt", "w");
}
void viewfile()
{
     char ch;
     fclose(fptr);
     FILE *fptr2;
     char file_name[100];
     printf("Enter file name: ");
     gets(file_name);
     strcat(file_name, ".txt");
     fptr2 = fopen(file_name, "r");

     if (fptr2 == NULL)
     {
          printf("Error creating/appending the file");
     }
     while ((ch = fgetc(fptr2)) != EOF)
     {
          printf("%c", ch);
     }
}
void edit()
{
     char ch;
     fclose(fptr);
     char file_name[100];
     printf("Enter file name: ");
     gets(file_name);
     strcat(file_name, ".txt");
     fptr = fopen(file_name, "a"); // Use "a" mode for appending/creating

     if (fptr == NULL)
     {
          printf("Error creating/appending the file");
     }
     // while ((ch = fgetc(fptr)) != EOF)
     // {
     //      printf("%c", ch);
     // }
     // fclose(fptr);
}