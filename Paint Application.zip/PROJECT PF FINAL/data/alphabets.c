#include"data_header.h"
void alphabetA(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
            
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                
                printf("*");
                fprintf(fptr,"*");}
               
            
            else
               
              { printf(" ");
               
               fprintf(fptr," ");}
        }
        for (int j = 1; j < i; j++)
        {
            if (j == size || i == size)
            {
                
                printf("*");
                fprintf(fptr,"*");}
            
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == i || i == size)
            {
                
                printf("*");
                fprintf(fptr,"*");}
            
            else
               
               {printf(" ");
               
               fprintf(fptr," ");}
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
        
    }
    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                
                printf("*");
                fprintf(fptr,"*");}
            
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }

        for (int j = 1; j < i; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
        }
        for (int j = 1; j <= i; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
        }

        int size1 = size * 2;

        for (int j = 1; j <= size1; j++)
        {
            if (j == size1)
            {
                
                printf("*");
                fprintf(fptr,"*");}
            
            else
               
               printf(" ");
               
               fprintf(fptr," ");
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetB(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (i = 1; i <= size; i++)
    {
        // Print the top horizontal line of B
        printf("%c", symbol);

        // Print the middle horizontal line of B
        for (j = 1; j <= size; j++)
        {
            if ((i == 1 || i == size / 2 + 1 || i == size) && j < size - 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else if (j == size - 1 && (i != 1 && i != size / 2 + 1 && i != size))
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }

        // Move to the next line
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetC(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
               
               printf(" ");
               
               fprintf(fptr," ");
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetD(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == 1 || j == size && i != 1 && i != size || i == 1 && j != size || i == size && j != size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetE(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        printf("%c", symbol);
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || i == size / 2 + 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetF(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        printf("%c", symbol);
        for (int j = 1; j <= size; j++)
        {
            if (i == 1  || i == size / 2 + 1 || j==1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetG(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (i = 0; i < size; i++)
    {
        for (j = 0; j < size; j++)
        {
            if ((i == 0 && (j >= 1 && j < size)) ||
                (i == size - 1 && (j >= 1 && j < size)) ||
                (j == 0 && (i >= 1 && i < size - 1)) ||
                ((i == size / 2) && (j >= size / 2)) ||
                ((j == size - 1) && (i >= size / 2)))
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetH(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (i = 1; i <= size; i++)
    {

        for (j = 1; j <= size; j++)
        {
            if (j == 1 || j == size || i == size / 2 + 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetI(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == size / 2 + 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetJ(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);

    for (int i = 1; i <= size ; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || j == size / 2 + 1 || i==size && j!=size && j!=size-1 && j!=size-2)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetK(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            if (j == size || j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetL(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == size || j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetM(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        for (int j = i; j < size; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
        }
        for (int j = i; j < size; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i || j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetN(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == 1 || j == size || i == j)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetO(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || i == size && j != 1 && j != size || j == size && i != 1 && i != size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetP(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 && j != size || i == size && j != size || j == 1 || j == size && i != 1 && i != size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetQ(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || i == size && j != 1 && j != size || j == size && i != 1 && i != size ||
                i == j && i != 1 && i != 2 && i != 3)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetR(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 && j != size || i == size && j != size || j == 1 || j == size && i != 1 && i != size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == 1 || i == j)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetS(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || j == size || i == size)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetT(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size + 1; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || j == size / 2 + 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetU(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == 1 || i == size || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetV(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        for (int j = i; j < size; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
        }
        for (int j = i; j < size; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetW(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);

    for (int i = 1; i <= size; i++)
    {

        for (int j = i; j <= size; j++)
        {
            if (j == i)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }

        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr,"  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr,"  ");
        }

        for (int j = i; j <= size; j++)
        {
            if (j == i)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }

        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
               
               printf(" ");
               
               fprintf(fptr," ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetX(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == j || i + j == size + 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetY(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr,"  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size + 1; j++)
        {
           
           printf(" ");
           
           fprintf(fptr," ");
        }

        for (int j = 1; j <= size; j++)
        {
            if (j == size / 2 + 1)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }

        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}

void alphabetZ(int size, char symbol, int x ,int y)
{
    int i, j;
    gotoxy(x,y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || i + j == size + 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr,"  ");
            }
        }
        
         printf("\n");
        fprintf(fptr,"\n");
        y++;
        gotoxy(x,y);
    }
}