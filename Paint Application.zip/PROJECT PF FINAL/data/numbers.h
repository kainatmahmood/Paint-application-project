void num1(int size, char symbol, int x ,int y);
void num2(int size, char symbol, int x ,int y);
void num3(int size , char  symbol, int x ,int y);
void num4(int size, char symbol, int x ,int y);
void num5(int size, char symbol, int x ,int y);
void num6(int size, char symbol, int x ,int y);
void num7(int size , char symbol, int x ,int y);
void num8(int size , char symbol, int x ,int y);
void num9(int size , char symbol, int x ,int y);