#include "data_header.h"
void num1(int size, char symbol, int x, int y)
{
    int i, j;
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == size || j == size / 2 + 1 || i == 2 && j != 1 && j != size - 1 && j != size - 2 && j != size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
          y++;
        gotoxy(x, y);

    }
}

void num2(int size, char symbol, int x, int y)
{
    int i, j;
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == size || i == 1 || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == 1 || i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        

        y++;
        gotoxy(x, y);
    }
}

void num3(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size / 2 + 1 || i == size || j == size)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        

        y++;
        gotoxy(x, y);
    }
}

void num4(int size, char symbol, int x, int y)
{
    gotoxy(x, y);
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == 1 || j == size || i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        

        y++;
        gotoxy(x, y);
    }
}

void num5(int size, char symbol, int x, int y)
{
    int i, j;
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == size || i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        

        y++;
        gotoxy(x, y);
    }
}

void num6(int size, char symbol, int x, int y)
{

    int i, j;
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == size || i == size || j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        

        y++;
        gotoxy(x, y);
    }
}

void num7(int size, char symbol, int x, int y)
{
    int i, j;
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i + j == size + 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        

        y++;
        gotoxy(x, y);
    }
}

void num8(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == 1 || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == size || i == size || j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        

        y++;
        gotoxy(x, y);
    }
}

void num9(int size, char symbol, int x, int y)
{
    gotoxy(x, y);

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == 1 || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        
        y++;
        gotoxy(x, y);
    }
}