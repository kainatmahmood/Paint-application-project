int gotoxy(int x, int y);
void bluecolour();
void redcolour();
void greencolour();
void yellowcolour();
void whitecolour();