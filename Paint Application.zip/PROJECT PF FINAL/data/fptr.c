#include"data_header.h"

FILE *fptr = NULL;