#define DATA_HEADER_FILE

#include"shapes.h"
#include"alphabets.h"
#include"numbers.h"
#include"utility_functions.h"

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <conio.h>
#include <windows.h>
#include<dirent.h>
#include<unistd.h>
extern FILE *fptr;
#define COLOR_RED     12
#define COLOR_GREEN   10
#define COLOR_YELLOW  14
#define COLOR_BLUE    9
#define COLOR_RESET   15
