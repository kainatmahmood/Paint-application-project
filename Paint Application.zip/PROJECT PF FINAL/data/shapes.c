#include "data_header.h"
void hollowsquare(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == 1 || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filledsquare(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowbutterfly(int size, char symbol, int x, int y)
{
    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            if (j == i || j == size)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            if (j == i || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}
void filledbutterfly(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)

        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowcircle(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || i == size && j != 1 && j != size || j == size && i != 1 && i != size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filledcircle(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || i <= size && j != 1 && j != size || j <= size && i != 1 && i != size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void drawhollowdiamond(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void drawfilleddiamond(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = 1; j < i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = i; j < size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void drawhollowpyramid(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (i == size || j == 1)

            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else

            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (i == size || j == size || j == i)

            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void drawfilledpyramid(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1, p = 1; j <= i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = 1; j < i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void printhollowheart(int size, char symbol, int x, int y)
{
    int i, j;

    // Print the top part of the heart
    for (i = size / 2; i <= size; i += 2)
    {
        for (j = 1; j < size - i; j += 2)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        for (j = 1; j <= size - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    // Print the bottom part of the heart
    for (i = size; i >= 1; i--)
    {
        for (j = i; j < size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (j = 1; j <= (i * 2) - 1; j++)
        {
            if (j == 1 || j == (i * 2) - 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void printfilledheart(int size, char symbol, int x, int y)
{
    int i, j;

    // Print the top part of the heart
    for (i = size / 2; i <= size; i += 2)
    {
        for (j = 1; j < size - i; j += 2)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (j = 1; j <= i; j++)
        {

            printf("%c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (j = 1; j <= size - i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (j = 1; j <= i; j++)
        {

            printf("%c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    // Print the bottom part of the heart
    for (i = size; i >= 1; i--)
    {
        for (j = i; j < size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (j = 1; j <= (i * 2) - 1; j++)
        {

            printf("%c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filledhexagon(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {

        for (int j = 1; j <= size + 1; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = 1; j <= size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = i; j < size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowhexagon(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {

        for (int j = 1; j <= size; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = 1; j <= size; j++)
        {
            if (j == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void drawhollowkite(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i || j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i || i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size || j == i || i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size / 2; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || i == size / 2)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == i || i == size / 2)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void drawfilledkite(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = 1; j < i; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        for (int j = i; j < size; j++)
        {
            printf(" %c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size / 2; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void horizontalline(int length, char symbol, int x, int y)
{
    for (int i = 1; i <= length; i++)
    {
        printf(" %c", symbol);
        fprintf(fptr, "%c", symbol);
    }
    printf("\n");
    fprintf(fptr, "\n");
}
void verticalline(int length, char symbol, int x, int y)
{
    int i, j;
    for (int j = 1; j <= length; j++)
    {
        printf("%c\n", symbol);
        fprintf(fptr, "%c\n", symbol);
    }
    printf("\n");
    fprintf(fptr, "\n");
}

void filledoval(int height, int width, char symbol, int x, int y)
{
    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= width; j++)
            if (i == 1 && j != width && j != 1 || j <= width && i != 1 && i != height ||
                j == 1 && i != 1 && i != height || i == height && j != 1 && j != width)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowoval(int height, int width, char symbol, int x, int y)
{
    for (int i = 1; i <= height; i++)
    {
        for (int j = 1; j <= width; j++)
        {
            if (i == 1 && j != width && j != 1 || j == width && i != 1 && i != height || j == 1 && i != 1 && i != height || i == height && j != 1 && j != width)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void printfilledparallelogram(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= size; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void printhollowparallelogram(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == size || j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowpentagon(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {

        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {

        for (int j = 1; j <= size; j++)
        {
            if (j == 1 || i == size || j == size)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filledpentagon(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)

        {
            printf("%c", symbol);
            fprintf(fptr, "%c", symbol);
        }

        for (int j = 1; j <= i; j++)
        {

            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {

            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void printhollowrectangle(int rows, int columns, char symbol, int x, int y)
{
    for (int i = 1; i <= rows; i++)
    {
        for (int j = 1; j <= columns; j++)
        {
            if (i == 1 || i == rows || j == 1 || j == columns)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void printfilledrectangle(int rows, int columns, char symbol, int x, int y)
{
    for (int i = 1; i <= rows; i++)
    {
        for (int j = 1; j <= columns; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowsandglass(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (i == 1 || j == i)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (i == 1 || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (i == size || j == 1)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else

            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (i == size || j == size || j == i)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filledsandglass(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        for (int j = i; j <= size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowstar(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = 1; j <= size; j++)
        {
            if (i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= size; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= size; j++)
        {
            printf("   ");
            fprintf(fptr, "   ");
        }
        for (int j = 1; j <= size; j++)
        {
            printf("   ");
            fprintf(fptr, "   ");
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= size; j++)
        {
            if (j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf(" ");
                fprintf(fptr, " ");
            }
        }

        for (int j = i; j <= size; j++)
        {
            if (j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filledstar(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= size; j++)
        {
            if (i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = 1; j < i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = 1; j <= size; j++)
        {
            if (i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = 1; j <= size; j++)
        {
            printf("%c  ", symbol);
            fprintf(fptr, "%c  ", symbol);
        }
        for (int j = 1; j <= size; j++)
        {
            printf("%c  ", symbol);
            fprintf(fptr, "%c  ", symbol);
        }
        for (int j = i; j <= size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);

            ;
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = i; j <= size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j < size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = i; j <= size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollow_4sided(int size, char symbol, int x, int y)
{
    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1 || j == i)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            if (j == i || j == size)

            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            if (j == i || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filled_4sided(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i < size; i++)
    {
        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {

            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)

        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void filledtrapezium(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= size; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }

        for (int j = 1; j < i; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void hollowtrapezium(int size, char symbol, int x, int y)
{
    int i, j;
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf(" ");
            fprintf(fptr, " ");
        }

        for (int j = 1; j <= size; j++)
        {
            if (i == 1 || i == size || j == 1)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }

        for (int j = 1; j <= i; j++)
        {
            if (j == i || i == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a increasing triangle

void increasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a hollow  increasing triangle
void hollowincreasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (i == size || j == 1 || j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a filled decreasing triangle
void decreasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a hollow decreasing triangle
void hollowdecreasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            if (i == 1 || j == i || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a filled right increasing triangle
void rightincreasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a hollow right increasing triangle
void hollowrightincreasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (i == size || j == 1 || j == i)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a filled right decreasing triangle
void rightdecreasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j <= size; j++)
        {
            printf("%c ", symbol);
            fprintf(fptr, "%c ", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

// Function to print a hollow right decreasing triangle
void hollowrightdecreasingtriangle(int size, char symbol, int x, int y)
{
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= size; j++)
        {
            if (i == 1 || j == i || j == size)
            {
                printf("%c ", symbol);
                fprintf(fptr, "%c ", symbol);
                
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void rightarrow(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {

            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size || i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void leftarrow(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {

            printf("  ");
            fprintf(fptr, "  ");
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i || i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (i == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void uparrow(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }
            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == i || j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }

        for (int j = i; j <= size; j++)
        {
            if (j == i)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}

void downarrow(int size, char symbol, int x, int y)
{
    int i, j;

    for (int i = 1; i < size; i++)
    {
        for (int j = i; j <= size; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j < i; j++)
        {

            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = 1; j <= i; j++)
        {
            if (j == 1)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
    for (int i = 1; i <= size; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("  ");
            fprintf(fptr, "  ");
        }
        for (int j = i; j < size; j++)
        {
            if (j == i)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        for (int j = i; j <= size; j++)
        {
            if (j == size || j == i)
            {
                printf(" %c", symbol);
                fprintf(fptr, "%c", symbol);
            }

            else
            {
                printf("  ");
                fprintf(fptr, "  ");
            }
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}
void chatbox1(char symbol, int size, int x, int y)
{
    int i, j;

    for (i = 0; i < size; i++)
    {
        if (i == 0 || i == size - 1)
        {

            for (j = 0; j < size + 2; j++)
            {
                printf("%c", symbol);
                fprintf(fptr, "%c", symbol);
            }
        }
        else
        {
            printf("%c", symbol);
            fprintf(fptr, "%c", symbol);

            for (j = 0; j < size; j++)
            {
                printf(" ");
                fprintf(fptr, " ");
            }
            printf("%c", symbol);
            fprintf(fptr, "%c", symbol);
        }
        printf("\n");
        fprintf(fptr, "\n");
        y++;
        gotoxy(x,y);
    }
}