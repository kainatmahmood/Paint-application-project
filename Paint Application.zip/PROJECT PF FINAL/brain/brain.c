#include "brain_header.h"
void colour(char col)
{
    if (col == 'r')
    {
        redcolour();
    }
    else if (col == 'b')
    {
        bluecolour();
    }
    else if (col == 'g')
    {
       greencolour();
    }
    else if (col == 'y')
    {
        yellowcolour();
    }
    else if (col == 'w')
    {
        whitecolour();
    }
}
 

#define COLOR_RED     12
#define COLOR_GREEN   10
#define COLOR_YELLOW  14
#define COLOR_BLUE    9
#define COLOR_RESET   15

void colorselection(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void square(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        hollowsquare(size, symbol, x, y);
    }
    else if (choice == 2)
    {
        filledsquare(size, symbol, x, y);
    }
}

void butterfly(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        hollowbutterfly(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        filledbutterfly(size, symbol, x, y);
    }
}

void circle(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        hollowcircle(size, symbol, x, y);
    }
    else if (choice == 2)
    {
        filledcircle(size, symbol, x, y);
    }
}

void diamond(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        drawhollowdiamond(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        drawfilleddiamond(size, symbol, x, y);
    }
}

void pyramid(int height, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        drawhollowpyramid(height, symbol, x, y);
    }

    else if (choice == 2)
    {
        drawfilledpyramid(height, symbol, x, y);
    }
}

void heart(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        printhollowheart(size, symbol, x, y);
    }
    else if (choice == 2)
    {
        printfilledheart(size, symbol, x, y);
    }
}

void hexagon(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        filledhexagon(size, symbol, x, y);
    }
    else if (choice == 2)
    {
        hollowhexagon(size, symbol, x, y);
    }
}

void kite(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        drawhollowkite(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        drawfilledkite(size, symbol, x, y);
    }
}

void line(int length, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        horizontalline(length, symbol, x, y);
    }
    else if (choice == 2)
    {
        verticalline(length, symbol, x, y);
    }
}

void oval(int height, int width, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        filledoval(height, width, symbol, x, y);
    }
    else if (choice == 2)
    {

        hollowoval(height, width, symbol, x, y);
    }
}

void parallalogram(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {

        printfilledparallelogram(size, symbol, x, y);
    }
    else if (choice == 2)
    {

        printhollowparallelogram(size, symbol, x, y);
    }
}

void pentagon(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        hollowpentagon(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        filledpentagon(size, symbol, x, y);
    }
}

void rectangle(int rows, int columns, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        printhollowrectangle(rows, columns, symbol, x, y);
    }
    else if (choice == 2)
    {
        printfilledrectangle(rows, columns, symbol, x, y);
    }
}

void sandglass(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        hollowsandglass(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        filledsandglass(size, symbol, x, y);
    }
}

void star(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        hollowstar(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        filledstar(size, symbol, x, y);
    }

    else if (choice == 3)
    {
        hollow_4sided(size, symbol, x, y);
    }

    else if (choice == 4)
    {
        filled_4sided(size, symbol, x, y);
    }
}

void trapezium(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        filledtrapezium(size, symbol, x, y);
    }
    else if (choice == 2)
    {
        hollowtrapezium(size, symbol, x, y);
    }
}

void triangle(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        increasingtriangle(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        hollowincreasingtriangle(size, symbol, x, y);
    }

    else if (choice == 3)
    {
        decreasingtriangle(size, symbol, x, y);
    }

    else if (choice == 4)
    {
        hollowdecreasingtriangle(size, symbol, x, y);
    }

    else if (choice == 5)
    {
        rightincreasingtriangle(size, symbol, x, y);
    }

    else if (choice == 6)
    {
        hollowrightincreasingtriangle(size, symbol, x, y);
    }

    else if (choice == 7)
    {
        rightdecreasingtriangle(size, symbol, x, y);
    }

    else if (choice == 8)
    {
        hollowrightdecreasingtriangle(size, symbol, x, y);
    }
}

void arrows(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        rightarrow(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        leftarrow(size, symbol, x, y);
    }

    else if (choice == 3)
    {
        uparrow(size, symbol, x, y);
    }

    else if (choice == 4)
    {
        downarrow(size, symbol, x, y);
    }
}
void chatbox(int size, char symbol, int x, int y)
{
    chatbox1(size, symbol, x, y);
}

void numbers(int size, int choice, char symbol, int x, int y)
{
    if (choice == 1)
    {
        num1(size, symbol, x, y);
    }

    else if (choice == 2)
    {
        num2(size, symbol, x, y);
    }

    else if (choice == 3)
    {
        num3(size, symbol, x, y);
    }

    if (choice == 4)
    {
        num4(size, symbol, x, y);
    }

    else if (choice == 5)
    {
        num5(size, symbol, x, y);
    }

    else if (choice == 6)
    {
        num6(size, symbol, x, y);
    }

    else if (choice == 7)
    {
        num7(size, symbol, x, y);
    }

    else if (choice == 8)
    {
        num8(size, symbol, x, y);
    }

    else if (choice == 9)
    {
        num9(size, symbol, x, y);
    }
}

void alphabets(int size, int choice, char symbol, int x, int y)
{
    if (choice == 'a')
    {
        alphabetA(size, symbol, x, y);
    }

    else if (choice == 'b')
    {
        alphabetB(size, symbol, x, y);
    }

    else if (choice == 'c')
    {
        alphabetC(size, symbol, x, y);
    }

    if (choice == 'd')
    {
        alphabetD(size, symbol, x, y);
    }

    else if (choice == 'e')
    {
        alphabetE(size, symbol, x, y);
    }

    else if (choice == 'f')
    {
        alphabetF(size, symbol, x, y);
    }

    else if (choice == 'g')
    {
        alphabetG(size, symbol, x, y);
    }

    else if (choice == 'h')
    {
        alphabetH(size, symbol, x, y);
    }

    else if (choice == 'i')
    {
        alphabetI(size, symbol, x, y);
    }

    if (choice == 'j')
    {
        alphabetJ(size, symbol, x, y);
    }

    else if (choice == 'k')
    {
        alphabetK(size, symbol, x, y);
    }

    else if (choice == 'l')
    {
        alphabetL(size, symbol, x, y);
    }

    else if (choice == 'm')
    {
        alphabetM(size, symbol, x, y);
    }

    else if (choice == 'n')
    {
        alphabetN(size, symbol, x, y);
    }

    else if (choice == 'o')
    {
        alphabetO(size, symbol, x, y);
    }

    else if (choice == 'p')
    {
        alphabetP(size, symbol, x, y);
    }

    else if (choice == 'q')
    {
        alphabetQ(size, symbol, x, y);
    }

    else if (choice == 'r')
    {
        alphabetR(size, symbol, x, y);
    }

    if (choice == 's')
    {
        alphabetS(size, symbol, x, y);
    }

    else if (choice == 't')
    {
        alphabetT(size, symbol, x, y);
    }

    else if (choice == 'u')
    {
        alphabetU(size, symbol, x, y);
    }

    else if (choice == 'v')
    {
        alphabetV(size, symbol, x, y);
    }

    else if (choice == 'w')
    {
        alphabetW(size, symbol, x, y);
    }

    else if (choice == 'x')
    {
        alphabetX(size, symbol, x, y);
    }

    else if (choice == 'y')
    {
        alphabetY(size, symbol, x, y);
    }

    else if (choice == 'z')
    {
        alphabetZ(size, symbol, x, y);
    }
}
