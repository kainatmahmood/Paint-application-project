#include".\interface\interface_header.h"
#include".\brain\brain_header.h"
#include".\data\data_header.h"
int main(){
    default_save();
    Main_Page();
     
    return 0;
}